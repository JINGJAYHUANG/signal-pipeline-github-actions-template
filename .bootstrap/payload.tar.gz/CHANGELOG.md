# Changelog

All notable changes are documented here.

## [0.1.0] - 2026-08-30

### Added

- Strict JSON configuration contract.
- Deterministic synthetic observation provider.
- Weighted-threshold selector and stable cross-date idempotency keys.
- Dry-run, file, console, and HTTPS webhook delivery semantics.
- Bounded retry policy for HTTP 429 and 5xx responses.
- Atomic JSON state and dedicated Git state-branch helper.
- Duplicate suppression with TTL and state-size bounds.
- Sanitized run artifacts with SHA-256 manifest.
- Health, run, init-state, and self-test CLI commands.
- Python 3.11–3.13 CI.
- Scheduled GitHub Actions workflow with safe dry-run default.
- Release workflow requiring an exact release branch at current `main`.
- Public-safety and workflow-pinning audit.
