# Contributing

Contributions should preserve the template's public and synthetic boundary.

## Workflow

1. Open an Issue for material behavior changes.
2. Create a focused branch.
3. Add or update failure-path tests.
4. Run `make check`.
5. Explain what the change proves and what remains outside its evidence.
6. Submit a Pull Request against `main`.

## Required properties

- No real credentials, private endpoints, customer data, market outputs, proprietary strategies, or licensed datasets.
- No unpinned GitHub Actions.
- No `pull_request_target` workflow without a separately reviewed threat model.
- No network access in unit tests or the built-in self-test.
- No state mutation before successful delivery.
- No broad exception handling that silently converts failure into success.
- New adapters must document their input, output, retry, idempotency, and redaction behavior.

## Commit guidance

Use descriptive messages such as:

```text
feat: add deterministic provider adapter
fix: preserve state after retry exhaustion
test: cover duplicate suppression across dates
docs: clarify webhook trust boundary
```
