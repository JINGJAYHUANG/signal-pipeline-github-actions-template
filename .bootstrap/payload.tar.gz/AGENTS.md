# Agent Instructions

Before editing, read the README, security model, failure semantics, and current tests.

Preserve these invariants:

1. Public examples remain synthetic.
2. Dry-run performs no network call and no persistent state mutation.
3. State changes only after successful live delivery semantics.
4. Secrets never enter logs, artifacts, state, fixtures, or source.
5. GitHub Actions remain pinned to full commit SHAs.
6. Failure paths receive tests before a completion claim is made.
