# Code of Conduct

Participate respectfully, discuss the implementation rather than individuals, and do not publish private data in repository discussions. Maintainers may remove abusive, deceptive, unsafe, or privacy-violating content.
