## Summary

## Behavior changed

## Failure paths tested

## State or idempotency impact

## Security and privacy review

- [ ] Public examples remain synthetic.
- [ ] No credential, private endpoint, personal data, or proprietary output is included.
- [ ] Dry-run remains network-free and state-free.
- [ ] State changes only after successful live delivery semantics.
- [ ] Referenced Actions are pinned to full commit SHAs.

## Verification boundary

Explain what the evidence proves and what it does not prove.
